package com.example.owner.newsapp;

import static org.junit.Assert.*;

/**
 * Created by Owner on 6/21/2017.
 */
public class NetworkUtilsTest {

}