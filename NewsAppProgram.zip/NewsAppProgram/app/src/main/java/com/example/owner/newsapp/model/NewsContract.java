package com.example.owner.newsapp.model;

import android.provider.BaseColumns;



public class NewsContract {
// A Contract holds all the columns of the table
    // inner class TABLE_ENTRY holds the columns and implements BaseColumns interface
    public static final class TABLE_ENTRY implements BaseColumns {
        // the table name is NewsTable
        public static final String TABLE_NAME = "NewsTable";
        // We have a column for authors called author
        public static final String COLUMN_NAME_AUTHOR = "author";
        // We have a column called title for the article titles
        public static final String COLUMN_NAME_TITLE = "title";
        //We have a column named descr that holds descriptions of the article
        public static final String COLUMN_NAME_DESCRIPTION = "descr";
        // We have a column named url that holds urls
        public static final String COLUMN_NAME_URL = "url";
        // We have a column named urlToImage that holds the url that houses an image
        public static final String COLUMN_NAME_URLTOIMAGE = "urlToImage";
        // We have a column name publishedAt that holds timestamp of the article
        public static final String COLUMN_NAME_PUBLISHEDAT = "publishedAt";
    }
}
