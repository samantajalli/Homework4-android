package com.example.owner.newsapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.owner.newsapp.model.DBHelper;
import com.example.owner.newsapp.model.DatabaseUtils;
import com.example.owner.newsapp.model.NewsItem;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;



// This class allows News articles (NewsItem) to be refreshed every second
public class RefreshNews {

    public static final String ACTION_REFRESH = "refresh";


    public static void refreshArticles(Context context) {
        ArrayList<NewsItem> result = null;
        URL url = NetworkUtils.buildUrl("the-next-web", "latest", "54a9ccbaf0874645903d2c513cfd9be6");

        SQLiteDatabase db = new DBHelper(context).getWritableDatabase();

        // wipe database clean and get json from url, parse it and insert it back into database
        try {
            DatabaseUtils.deleteAll(db);
            String json = NetworkUtils.getResponseFromHttpUrl(url);
            result = NetworkUtils.parseJSON(json);
            DatabaseUtils.bulkInsert(db, result);

        } catch (IOException e) {
            e.printStackTrace();

        } catch (JSONException e) {
            e.printStackTrace();
        }

        db.close();
    }
}
