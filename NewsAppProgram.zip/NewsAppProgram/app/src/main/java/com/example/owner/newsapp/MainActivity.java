package com.example.owner.newsapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.example.owner.newsapp.model.DBHelper;
import com.example.owner.newsapp.model.DatabaseUtils;
import com.example.owner.newsapp.model.NewsContract;
import com.example.owner.newsapp.model.NewsItem;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<Void>, NewsAdapter.ItemClickListener {
    static final String TAG = "MainActivity";
    private EditText search;
    private ProgressBar progress;
    private RecyclerView rv;
    private NewsAdapter adapter;
    private Cursor cursor;
    private SQLiteDatabase db;
    //uniquely identify the loader
    private static final int NEWS_LOADER = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = (EditText) findViewById(R.id.searchQuery);
        progress = (ProgressBar) findViewById(R.id.progressBar);

        db = new DBHelper(MainActivity.this).getReadableDatabase();
        cursor = DatabaseUtils.getAll(db);
        // cursor points to table

        NewsAdapter.ItemClickListener adapters = this;
       adapter = new NewsAdapter(this,cursor);
        // adapter provides a binding from app specific data set to views displayed within
        // RecyclerView

        rv = (RecyclerView) findViewById(R.id.recyclerview_news);
        rv.setLayoutManager(new LinearLayoutManager(this));
        // display the data

        // Shared Preferences is an interface
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isFirst = prefs.getBoolean("isfirst", true); // isfirst is the key value, set to true

        if (isFirst) {
            // call the loading manager
            loadThem();
            // intializes all the values in the asyncloader
            getSupportLoaderManager().initLoader(NEWS_LOADER, null, this);

            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isfirst", false); // we set the key value to false
            editor.commit();
            // save changes to the SharedPrefences editor. we know now that we called the
            // LoaderManager and we will not do it again
        }
        ScheduleUtil.scheduleRefresh(this);




    }
    // called at beginning of Activity after onCreate
    @Override
    protected void onStart(){
        super.onStart();
        db = new DBHelper(MainActivity.this).getReadableDatabase();
        cursor = DatabaseUtils.getAll(db);
        adapter = new NewsAdapter(this, cursor);
        rv.setAdapter(adapter);
    }

    // called when Activity stops
    @Override
    protected void onStop(){
        super.onStop();
        db.close();
        cursor.close();
    }

    // this method loads the data if not already done so, and notifies the adapter that the data set
    // has changed
    private void loadThem() {
        LoaderManager loaderManager = getSupportLoaderManager();
        loaderManager.restartLoader(NEWS_LOADER, null, this).forceLoad();
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemNumber = item.getItemId();

        if (itemNumber == R.id.search) {
            String s = search.getText().toString();
            loadThem();

        }
        return true;

    }

    // when you click on a NewsItem article, the cursor will grab that record, take the url,
    // use an intent to start an Activity which will open the article to its respective web page
    @Override
    public void onItemClick(Cursor cursor, int clickedItemIndex) {

        cursor.moveToPosition(clickedItemIndex);
        String url = cursor.getString(cursor.getColumnIndex(NewsContract.TABLE_ENTRY.COLUMN_NAME_URL));
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    // Declare and return AsyncTaskLoader from within a Loader. What this mean is that the Loader
    // provides a functional AsyncTask to do work within the app.
    // AsyncTaskLoader has its own lifecycle and configuration changes do not affect it,
    // unlike AsyncTask as it is connected to host activity lifecycle.
    

    @Override
    public Loader<Void> onCreateLoader(int id, final Bundle args) {

        return new AsyncTaskLoader<Void>(this) {

            // analogue to onPreExecute  on AsyncTask, will check the args for info
            @Override
            protected void onStartLoading() {
                if (args != null) {
                    Log.d(TAG, "no new info ");
                }
                super.onStartLoading();
                progress.setVisibility(View.VISIBLE);
            }

            // run the json in the background before it is displayed in onPostExecute
            @Override
            public Void loadInBackground() {

                RefreshNews.refreshArticles(MainActivity.this);
                return null;
            }
        };
    }


    // OnLoadFinished works the same way as onPostExecute does on AsyncTask.
    // Get the Database, get the Cursor.
    // Display the json object articles (NewsItem)

    @Override
    public void onLoadFinished(Loader<Void> loader,Void data) {
        progress.setVisibility(View.GONE);
        db = new DBHelper(MainActivity.this).getReadableDatabase();
        cursor = DatabaseUtils.getAll(db);

        adapter = new NewsAdapter(this, cursor);
        rv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(Loader<Void> loader) {

    }

}