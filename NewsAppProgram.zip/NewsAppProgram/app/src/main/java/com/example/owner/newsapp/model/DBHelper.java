package com.example.owner.newsapp.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;



public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "NewsTable.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TAG = "dbhelper";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // creates the table with columns defined
    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_NEWS_TABLE = "CREATE TABLE " + NewsContract.TABLE_ENTRY.TABLE_NAME + " ( " +
                NewsContract.TABLE_ENTRY._ID + "INTEGER PRIMARY AUTOINCREMENT, " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_AUTHOR + " TEXT NOT NULL " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_TITLE+ " TEXT NOT NULL " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_DESCRIPTION + " TEXT NOT NULL " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_URL + " TEXT NOT NULL " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_URLTOIMAGE + " TEXT NOT NULL " +
                NewsContract.TABLE_ENTRY.COLUMN_NAME_PUBLISHEDAT + " DATE " + ");";

        Log.d(TAG, "Create table SQL: " + SQL_CREATE_NEWS_TABLE);
        db.execSQL(SQL_CREATE_NEWS_TABLE);

    }

    // To make future changes to the table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table " + NewsContract.TABLE_ENTRY.TABLE_NAME + " if exists;");
    }
}
