package com.example.owner.newsapp.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_AUTHOR;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_DESCRIPTION;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_PUBLISHEDAT;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_TITLE;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_URL;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.COLUMN_NAME_URLTOIMAGE;
import static com.example.owner.newsapp.model.NewsContract.TABLE_ENTRY.TABLE_NAME;



public class DatabaseUtils {

    // return the database table
    // the Cursor provides an interface to read and write a table returned by a query
    // here, the cursor returns the table it points to
    public static Cursor getAll(SQLiteDatabase db) {
        Cursor cursor = db.query(
                TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                COLUMN_NAME_PUBLISHEDAT + " DESC"
        );
        return cursor;
    }

    // insert into the table
    public static void bulkInsert(SQLiteDatabase db, ArrayList<NewsItem> articles) {

        db.beginTransaction();
        try {
            for (NewsItem a : articles) {
                ContentValues cv = new ContentValues();
                cv.put(COLUMN_NAME_TITLE, a.getTitle());
                cv.put(COLUMN_NAME_AUTHOR, a.getAuthor());
                cv.put(COLUMN_NAME_DESCRIPTION, a.getDescription());
                cv.put(COLUMN_NAME_PUBLISHEDAT, a.getPublishedAt());
                cv.put(COLUMN_NAME_URLTOIMAGE, a.getUrlToImage());
                cv.put(COLUMN_NAME_URL, a.getUrl());
                db.insert(TABLE_NAME, null, cv);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public static void deleteAll(SQLiteDatabase db) {
        db.delete(TABLE_NAME, null, null);
    }

}
