package com.example.owner.newsapp;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.AsyncTask;
import android.widget.Toast;



// JobService class handles asynchronous tasks previously scheduled
// we have an intent filter in AndroidManifest.xml to execute this job service
public class NewsJob extends JobService{

    AsyncTask mBackgroundTask;

    //onStartJob implements job logic
    // onStartJob will return a new AsyncTask that will initially display text stating the news is refreshing,
    // while proceeding to refresh periodically in the background.
    // jobFinished informs the JobManager that execution of the job is complete.
    @Override
    public boolean onStartJob(final JobParameters job) {
        mBackgroundTask = new AsyncTask() {
            @Override
            protected void onPreExecute() {
                Toast.makeText(NewsJob.this, "News refreshed", Toast.LENGTH_SHORT).show();
                super.onPreExecute();
            }

            @Override
            protected Object doInBackground(Object[] params) {
                RefreshNews.refreshArticles(NewsJob.this);
                return null;
            }

            @Override
            protected void onPostExecute(Object o) {
                jobFinished(job, false);
                super.onPostExecute(o);

            }
        };


        mBackgroundTask.execute();

        return true;
    }

    //This is called if system determines that execution of your job needs to be stopped
    // prematurely before you call jobFinished
    @Override
    public boolean onStopJob(JobParameters job) {

        if (mBackgroundTask != null) mBackgroundTask.cancel(false);

        return true;
    }

}
